# Make sure to change the Handler into "snapshot.lambda_handler" under Code > Runtime Settings > Edit > Handler
from requests_aws4auth import AWS4Auth
import boto3
import requests

def lambda_handler(event, context):
    host = '<domain endpoint with https and a trailing slash without these angular brackets>'
    path = '_snapshot/<name_of_repository>'
    region = '<domain region like us-east-1>'
    service = 'es'
    credentials = boto3.Session().get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)
    url = host + path;
    headers = {"Content-Type": "application/json"};
    payload={
    "type": "s3",
    "settings": {
        "bucket": "<bucket_name>",
        "region": "us-east-1",
        "role_arn": "<role_arn>"
    }
    }   
    r = requests.put(url, auth=awsauth, json=payload, headers=headers);
    print(r.status_code)
    print(r.text)
    return {
        'status_code':r.status_code,
        'response':r.text
    }


